import React, { useState } from 'react';
import axios from 'axios';

function Register() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = async(e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:4000/api/register', { username, password });
            alert('Registration successful! You can now log in.');
        } catch (error) {
            setError('Error registering user. Please try again.');
            console.error('Error registering:', error);
        }
    };

    return ( <
        form onSubmit = { handleSubmit } >
        <
        div >
        <
        label > Username: < /label> <
        input type = "text"
        value = { username }
        onChange = {
            (e) => setUsername(e.target.value) }
        required / >
        <
        /div> <
        div >
        <
        label > Password: < /label> <
        input type = "password"
        value = { password }
        onChange = {
            (e) => setPassword(e.target.value) }
        required / >
        <
        /div> {
            error && < p > { error } < /p>} <
                button type = "submit" > Register < /button> <
                /form>
        );
    }

    export default Register;